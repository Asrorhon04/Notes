function Main() {
	return (
		<div className="container mt-5">
			<div className="btn btn-primary me-3">
				<a href="/create" className="text-light">Создать Note</a>
			</div>
			<div className="btn btn-primary ms-3">
				<a href="/note" className="text-light">Просмотреть Note</a>
			</div>

		</div>
	);
}

export default Main;

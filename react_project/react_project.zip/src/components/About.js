function About() {
	return (
		<div className="container">
			<p className="text-success fs-3 mt-5 text-center">Сайт создает закодированные заметки для собственного использования или отправку другим пользователям.</p>
		</div>
	);
}

export default About;
